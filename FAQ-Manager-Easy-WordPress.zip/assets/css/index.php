<?php
// Silenzio è d'oro.
?> 